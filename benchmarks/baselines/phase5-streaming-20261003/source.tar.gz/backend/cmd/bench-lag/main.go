// bench-lag takes bounded, read-only Kafka offset snapshots without a JVM.
package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"github.com/twmb/franz-go/pkg/kgo"
	"github.com/twmb/franz-go/pkg/kmsg"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"
)

func positions(ctx context.Context, c *kgo.Client, topic, group string) (int64, int64, error) {
	f := kmsg.NewPtrOffsetFetchRequest()
	f.Group = group
	f.Topics = []kmsg.OffsetFetchRequestTopic{{Topic: topic, Partitions: []int32{0}}}
	g := kmsg.NewOffsetFetchRequestGroup()
	g.Group = group
	g.Topics = []kmsg.OffsetFetchRequestGroupTopic{{Topic: topic, Partitions: []int32{0}}}
	f.Groups = []kmsg.OffsetFetchRequestGroup{g}
	response, err := f.RequestWith(ctx, c)
	if err != nil {
		return 0, 0, err
	}
	committed := int64(-1)
	if len(response.Groups) == 1 {
		g := response.Groups[0]
		if g.ErrorCode != 0 || len(g.Topics) != 1 || len(g.Topics[0].Partitions) != 1 || g.Topics[0].Partitions[0].ErrorCode != 0 {
			return 0, 0, errors.New("invalid group offset response")
		}
		committed = g.Topics[0].Partitions[0].Offset
	} else {
		if response.ErrorCode != 0 || len(response.Topics) != 1 || len(response.Topics[0].Partitions) != 1 || response.Topics[0].Partitions[0].ErrorCode != 0 {
			return 0, 0, errors.New("invalid legacy group offset response")
		}
		committed = response.Topics[0].Partitions[0].Offset
	}
	// Read end after committed: this is a sequential observation, not an atomic
	// snapshot. Nonzero lag can include concurrent production between requests.
	req := kmsg.NewPtrListOffsetsRequest()
	p := kmsg.NewListOffsetsRequestTopicPartition()
	p.Partition = 0
	p.Timestamp = -1
	req.Topics = []kmsg.ListOffsetsRequestTopic{{Topic: topic, Partitions: []kmsg.ListOffsetsRequestTopicPartition{p}}}
	end, err := req.RequestWith(ctx, c)
	if err != nil {
		return 0, 0, err
	}
	if len(end.Topics) != 1 || len(end.Topics[0].Partitions) != 1 || end.Topics[0].Partitions[0].ErrorCode != 0 {
		return 0, 0, errors.New("invalid end offset response")
	}
	return committed, end.Topics[0].Partitions[0].Offset, nil
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func run() error {
	output := flag.String("output", "", "new JSONL file")
	brokers := flag.String("brokers", "127.0.0.1:19092", "Kafka endpoints")
	topic := flag.String("topic", "incidentlens-spans-v1", "single-partition topic")
	group := flag.String("group", "incidentlens-stream-worker-v1", "consumer group")
	duration := flag.Duration("duration", 15*time.Minute, "hard observation bound (maximum15m)")
	flag.Parse()
	if *output == "" || *duration <= 0 || *duration > 15*time.Minute {
		return errors.New("output and bounded duration required")
	}
	file, err := os.OpenFile(*output, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	defer file.Close()
	client, err := kgo.NewClient(kgo.SeedBrokers(strings.Split(*brokers, ",")...))
	if err != nil {
		return err
	}
	defer client.Close()
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	ctx, cancel := context.WithTimeout(ctx, *duration)
	defer cancel()
	encoder := json.NewEncoder(file)
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()
	samples := 0
	for {
		if ctx.Err() != nil {
			break
		}
		started := time.Now()
		attempt, end := context.WithTimeout(ctx, 2*time.Second)
		committed, latest, err := positions(attempt, client, *topic, *group)
		end()
		if ctx.Err() != nil {
			break
		}
		value := map[string]any{"kind": "lag", "started_ns": started.UnixNano(), "finished_ns": time.Now().UnixNano(), "duration_ns": time.Since(started).Nanoseconds()}
		if err != nil {
			value["error"] = err.Error()
		} else {
			value["committed"] = committed
			value["end"] = latest
			if committed >= 0 && latest >= committed {
				value["lag_records"] = latest - committed
			} else {
				value["uninitialized_or_inconsistent"] = true
			}
		}
		if err = encoder.Encode(value); err != nil {
			return err
		}
		samples++
		select {
		case <-ctx.Done():
		case <-ticker.C:
		}
	}
	return encoder.Encode(map[string]any{"kind": "observer_end", "samples": samples, "finished_ns": time.Now().UnixNano()})
}
